CMS Made Simple Version 2.2.16
------------------------------
NOTE: Although all efforts have been made to make this release compatible with PHP8, you may experience issues in some server environments, so testing is highly recommended before switching PHP versions on a production site.
NOTE: Most likely not all 3rd Party modules are compatible either so, if you find issues with theses modules, please file BR with the respective module developers.
NOTE: We have dropped support to PHP 5.6 in this release. The minimum PHP version now supported is 7.0 although we strongly recommend 7.4+ for security and performance.