Quick notes for debugging/developing the .phar installer

1:
--
For developing with the .phar installer without building the thing for each test
specify a ?dest=/full/path/to/directory argument on the INITIAL url

i.e:  http://www.mysite.com/phar_installer/index.php?dest=/var/www/cmsms_dir

