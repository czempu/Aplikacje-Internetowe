<?php
$lang['action_freshen'] = 'Refrescant / Reparant %s instal.lació  de CMS';
$lang['action_install'] = 'Creant un nou web %s CMSMS';
$lang['action_upgrade'] = 'Actualitzant un Web CMSMS a versió %s';
$lang['advanced_mode'] = 'Habilita el mode avançat';
?>