<?php
$lang['advanced_mode'] = 'Aktivera avancerade inställningar';
$lang['available_languages'] = 'Tillgängliga språk';
$lang['cleaning_files'] = 'Rensar bort filer som inte längre behövs i den här utgåvan';
$lang['config_writable'] = 'Kontrollerar skrivbarhet för configurationsfilen';
$lang['confirm_freshen'] = 'Är du säker på att du vill uppgradera (reparera) den existerande installationen av CMSMS? Gå endast vidare om du är säker!';
$lang['confirm_upgrade'] = 'Är du säker på att du vill påbörja uppgraderingsprocessen?';
$lang['done'] = 'färdig';
$lang['email_accountinfo_message'] = 'Din installation av CMS Made Simple är slutförd.

Detta meddelande innehåller känslig information och bör hanteras/lagras på ett säkert sätt.

Detaljer för din installation:
Användarnamn: %s
Lösenord: %s
Installationsmapp: %s
Root URL: %s';
$lang['email_accountinfo_message_exp'] = 'Din installation av CMS Made Simple är slutförd.

Detta meddelande innehåller känslig information och bör hanteras/lagras på ett säkert sätt.

Detaljer för din installation:
Användarnamn: %s
Lösenord: %s
Installationsmapp: %s';
$lang['title_step2'] = 'Steg 2 - Söker befintliga program';
$lang['title_step3'] = 'Steg 3 - Tester';
$lang['title_step4'] = 'Steg 4 - Grundläggande konfiguration';
$lang['title_step5'] = 'Steg 5 - Administratörskontot';
$lang['title_step6'] = 'Steg 6 - Webbplatsinställningar';
$lang['title_step7'] = 'Steg 7 - Installation av programfiler';
$lang['title_step8'] = 'Steg 8 - Databasinställningar';
$lang['title_step9'] = 'Steg 9 - Slutför';
$lang['title_welcome'] = 'Välkommen';
$lang['title_forum'] = 'Supportforum';
$lang['title_docs'] = 'Officiell dokumentation';
$lang['title_api_docs'] = 'Officiell API-dokumentation';
$lang['to'] = 'till';
$lang['title_share'] = 'Dela dina erfarenheter med dina vänner.';
$lang['wizard_step1'] = 'Välkommen';
$lang['yes'] = 'Ja';
?>