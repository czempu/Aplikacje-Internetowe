<?php

namespace __appbase;

function &get_db()
{
  require_once(dirname(__DIR__).'/adodb_lite/adodb.inc.php');
  
}

?>